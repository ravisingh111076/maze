package uk.gov.dwp.maze;

public class Maze {
}
