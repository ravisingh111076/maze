package uk.gov.dwp.maze;

import lombok.Builder;

import java.awt.*;

public class ExitMazeBlock extends MazeBlock {

    Color foreColor = Color.BLUE;

    @Builder(builderMethodName = "exitMazeBlock")
    public ExitMazeBlock(String face,
                          int xCoordinate,
                          int yCoordinate) {
        super(face,xCoordinate,yCoordinate, MazeBlockType.EndBlock);
        super.setForeground(foreColor);
    }
}
