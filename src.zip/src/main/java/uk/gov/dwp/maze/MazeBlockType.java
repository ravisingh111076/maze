package uk.gov.dwp.maze;

public enum MazeBlockType {
   emptySpace, NonEmptySpace, StartBlock, EndBlock
}
