package uk.gov.dwp.maze.service;

import uk.gov.dwp.maze.Maze;
import uk.gov.dwp.maze.MazeBlock;

import java.util.List;

public interface MazeDataService {
    
    Maze getMazeData();


}
