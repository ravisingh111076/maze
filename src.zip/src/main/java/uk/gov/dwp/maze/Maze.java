package uk.gov.dwp.maze;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//TODO implement as singleton
public class Maze {
    private static Maze maze;
    @Setter
    @Getter
    private MazeBlock startMazeBlock;
    @Setter
    @Getter
    private MazeBlock exitMazeBlock;
    @Setter
    @Getter
    private List<MazeBlock> blocks = new ArrayList<>();

    private Maze() {}

    private void validateBlockAndAssignStartAndExitBlock(MazeBlock mazeBlock) {
        if(mazeBlock.blockType.equals(MazeBlockType.StartBlock)) {
            if(maze.startMazeBlock !=null) throw new RuntimeException("multiple start found, bad file");
            else maze.startMazeBlock = mazeBlock;
        } else if(mazeBlock.blockType.equals(MazeBlockType.EndBlock)) {
            if(maze.exitMazeBlock!=null) throw new RuntimeException("multiple end found, bad file");
            else maze.exitMazeBlock = mazeBlock;
        }
    }

    public synchronized static Maze buildMazeFromTextFile(String filePath, int col, int row) {
        maze = new Maze();
        int rowCounter = 0;
        int colCounter = 0;
        try {
            Scanner scanner = new Scanner(Maze.class.getResourceAsStream(filePath));
            while (scanner.hasNextLine()) {
                // Read in a single character
                MazeBlock mazeBlock = MazeBlockFactory.buildMazeBlock(
                        scanner.findInLine(".").charAt(0), colCounter, rowCounter);
                maze.validateBlockAndAssignStartAndExitBlock(mazeBlock);
                maze.blocks.add(mazeBlock);
                colCounter++;
                if (colCounter == col) {
                    // Consume the line break
                    if(rowCounter < row - 1)
                        scanner.nextLine();
                    // Move to the next row
                    rowCounter++;
                    colCounter = 0;
                }
            }
            if(maze.startMazeBlock==null || maze.exitMazeBlock ==null)
                throw new RuntimeException("Bad Maze file, either start or end missing");
        } catch (Exception e) {
            throw new RuntimeException("Exception while reading from file" + e.getMessage());
        }
        return maze;
    }
}
