package uk.gov.dwp.maze;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import java.awt.*;

@Getter
@Setter
public class StartMazeBlock extends MazeBlock {
    Color foreColor = Color.RED;
    @Builder(builderMethodName = "startMazeBuilder")
    public StartMazeBlock(String face,
                          int xCoordinate,
                          int yCoordinate) {
        super(face, xCoordinate, yCoordinate, MazeBlockType.StartBlock);
        super.setForeground(foreColor);
    }
}
