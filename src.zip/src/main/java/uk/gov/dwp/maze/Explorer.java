package uk.gov.dwp.maze;

public class Explorer {

    public static void main(String [] args) {
        MazeUI mazeUI = new MazeUI();
        mazeUI.display();
    }
}
