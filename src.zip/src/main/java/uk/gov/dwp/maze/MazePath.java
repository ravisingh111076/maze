package uk.gov.dwp.maze;

public class MazePath {
    MazeBlock currentMazeBlock;
    Maze maze;

    public MazePath(Maze maze) {
        this.currentMazeBlock = maze.getStartMazeBlock();
        this.maze = maze;
    }

    public boolean moveLeft() {
        MazeBlock leftMaze = maze.getBlocks().get(currentIndex() - 1);
        if(leftMaze.getBlockType().equals(MazeBlockType.emptySpace)) {
            //move current Index
            currentMazeBlock = leftMaze;
            leftMaze.setText("<-");
            return true;
        } else {
            return false;
        }
    }

    private int currentIndex() {
        return currentMazeBlock.getXCoordinate() + currentMazeBlock.getYCoordinate() * 15;
    }

    public boolean moveRight() {
        MazeBlock rightMaze = maze.getBlocks().get(currentIndex() + 1);
        if(rightMaze.getBlockType().equals(MazeBlockType.emptySpace)) {
            currentMazeBlock = rightMaze;
            rightMaze.setText("->");
            return true;
        } else {
            return false;
        }
    }

    public boolean moveUp() {
        int upIndex = currentMazeBlock.getXCoordinate() + (currentMazeBlock.getYCoordinate()-1) * 15;
        MazeBlock UpMaze = maze.getBlocks().get(upIndex);
        if(UpMaze.getBlockType().equals(MazeBlockType.emptySpace)) {
            currentMazeBlock = UpMaze;
            UpMaze.setText("|");
            return true;
        } else {
            return false;
        }
    }

    public boolean moveDown() {
        int upIndex = currentMazeBlock.getXCoordinate() + (currentMazeBlock.getYCoordinate()+1) * 15;
        MazeBlock UpMaze = maze.getBlocks().get(upIndex);
        if(UpMaze.getBlockType().equals(MazeBlockType.emptySpace)) {
            currentMazeBlock = UpMaze;
            UpMaze.setText("|");
            return true;
        } else {
            return false;
        }
    }
}
