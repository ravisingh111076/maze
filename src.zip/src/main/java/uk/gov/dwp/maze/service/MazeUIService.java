package uk.gov.dwp.maze.service;

public interface MazeUIService {
}
