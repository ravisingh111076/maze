package uk.gov.dwp.maze;
import lombok.*;

import javax.swing.*;

@Builder
@Getter
@Setter
@EqualsAndHashCode
public class MazeBlock extends JLabel {
    private String face;
    private int xCoordinate;
    private int yCoordinate;
    MazeBlockType blockType;

    public MazeBlock(String face, int x, int y, MazeBlockType mazeBlock) {
        super(face);
        this.face = face;
        this.xCoordinate = x;
        this.yCoordinate = y;
        this.blockType = mazeBlock;
    }
}
