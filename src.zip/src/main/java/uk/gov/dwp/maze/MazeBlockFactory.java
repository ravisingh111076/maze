package uk.gov.dwp.maze;

public class MazeBlockFactory {

    public static MazeBlock buildMazeBlock(char mazeType, int x, int y) {
            switch (mazeType) {
                case 'S' :
                    return StartMazeBlock.startMazeBuilder()
                            .face(Character.toString(mazeType))
                            .xCoordinate(x).yCoordinate(y).build();
                case 'F':
                    return ExitMazeBlock.exitMazeBlock()
                            .face(Character.toString(mazeType))
                            .xCoordinate(x).yCoordinate(y).build();
                case 'X':
                    return MazeBlock.builder()
                            .face(Character.toString(mazeType))
                            .blockType(MazeBlockType.NonEmptySpace)
                            .xCoordinate(x).yCoordinate(y).build();
                 default:
                    return MazeBlock.builder()
                            .face(Character.toString(mazeType))
                            .blockType(MazeBlockType.emptySpace)
                            .xCoordinate(x).yCoordinate(y).build();
            }
        }
}
